
# VerificaADV - Backend

Backend da plataforma VerificaADV.

## Instalação
1. Instale as dependências:
```
npm install
```

2. Rode o servidor:
```
npm start
```

## Variáveis de ambiente
Veja o arquivo `.env.example`.
